const MESSAGES = [
  `<h1>Tutoren streiken!!!</h1>
    <h2>Alle Einsendeaufgaben werden ab sofort mit 0 Punkten bewertet</h2>
    <p>[&hellip;]</p>
    <p>am 25.09.2015 von K. Einer</p>`,

  `<h1>Wahnsinn!</h1>
    <h2>Wie ich mit einer dämlichen Idee ein Vermögen machte</h2>
    <p>[&hellip;]</p>
    <p>am 13.08.2015 von Dr. B. Lödmann</p>`,

  `<h1>Prokrastination?</h1>
    <h2>Wie oft hörst du dich selbst sagen: „Nein, ich hab's noch nicht erledigt; ich habe es vor!“</h2>
    <p>[&hellip;]</p>
    <p>am 02.06.2015 von A. Meisenbär</p>`,
];
