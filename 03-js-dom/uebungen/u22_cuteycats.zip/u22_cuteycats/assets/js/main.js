'use strict';

(() => {
  // === DOM & VARS =======
  const DOM = {};

  // === INIT =============
  const init = () => {};

  // === EVENTHANDLER =====

  // === XHR/FETCH ========

  // === FUNCTIONS ========

  init();
})();
